//
//  Registry.h
//  Registry
//
//  Created by Angelo Di Paolo on 3/19/20.
//  Copyright © 2020 Angelo Di Paolo. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Registry.
FOUNDATION_EXPORT double RegistryVersionNumber;

//! Project version string for Registry.
FOUNDATION_EXPORT const unsigned char RegistryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Registry/PublicHeader.h>


